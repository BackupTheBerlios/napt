<?php

$tpl = '';
if ( isset( $_GET['doc'] ) ) $tpl = $_GET['doc'];
if ( $tpl == '' ) $tpl = 'overview';

$napt->setGlobal( 'content', $napt->getTemplate( $tpl ) );

?>
