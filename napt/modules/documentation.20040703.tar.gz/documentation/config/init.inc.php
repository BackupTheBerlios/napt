<?php

include( 'modules/'.$napt->module.'/config/config.cfg.php' );

?>
