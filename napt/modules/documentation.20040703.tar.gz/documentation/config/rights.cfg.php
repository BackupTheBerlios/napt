<?php

/* die rights.cfg.php wird immer eingebunden, daher gibt es
 * $napt->module nicht!
 */

$MODULE_NAME = Misc::getParentDir( __FILE__, false );

$rights[$MODULE_NAME] = array();
$rights[$MODULE_NAME]['overview']   = '*';

?>
