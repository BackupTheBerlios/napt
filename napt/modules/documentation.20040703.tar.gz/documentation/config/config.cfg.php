<?php

$cfg[$napt->module] = array();

?>
