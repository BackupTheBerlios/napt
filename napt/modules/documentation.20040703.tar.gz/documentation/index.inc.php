<?php
include( 'modules/'.$napt->module.'/config/init.inc.php' );

$napt->setGlobal( 'title', 'Dokumentation' );
$napt->setGlobal( 'menu', $napt->getTemplate( 'submenu', 'mnu' ) );

if ( $napt->isAllowed( $napt->module, $napt->action ) && ( $napt->action != "" ) ) {
	include( 'scripts/'.$napt->action.'.inc.php' );
} 

if ( $napt->isAllowed( $napt->module, $napt->view ) && ( $napt->view != "" ) ) {
	include( 'scripts/'.$napt->view.'.inc.php' );
} else {
	//@ToDo Tja, was nun Max?
};
?>
