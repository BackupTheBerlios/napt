<?php

$content = $napt->getAdminTemplate( 'newtext' );
$napt->setGlobal( 'content', $content );

?>