<?php

$thisDb = $napt->getDatabase( $cfg[$napt->module]['dsn'] );
$content = $napt->getTemplate( 'text' );

/* Templates Filtern */
$acontent = explode( '<!-- input.template -->', $content ); $content = $acontent[0].$acontent[2];
$tplInput = $acontent[1];

/* Text mit Lücken und Inputs füllen */
$text = $thisDb->queryObject( 'SELECT id, name, grad, ltext, kategorie FROM ltext WHERE id = '.$HTTP_GET_VARS['id'] );
$text->ltext = htmlentities( $text->ltext );
$atext = explode( '@', $text->ltext );
$count = 0;
foreach ( $atext as $partText ) {
	if ( $count == 0 ) {
		$htmltext = $partText;
	} else {
		$wortId = substr($partText, 0, strpos( $partText, ' ') );
		$htmltext .= ereg_replace( "<!-- id -->", $wortId, $tplInput );
		$htmltext .= substr( $partText, strpos( $partText, ' ') );
	}
	$count++;
}



/* HTML Kommentare ersetzen */
$content = ereg_replace( '<!-- text.ltext -->', $htmltext , $content );
$content = ereg_replace( '<!-- text.id -->', $text->id, $content );
$content = ereg_replace( '<!-- text.name -->', htmlentities( $text->name ), $content );

$napt->setGlobal( 'content', $content );
$napt->setGlobal( 'pagename', 'L&uuml;ckentext - Text "'.$text->name.'"' );
?>