<?php

$mydb  = $napt->getDatabase( $cfg[$napt->module]['dsn'] );
$mytpl = $napt->getTemplate( 'overview' );

$allReplace = array();
$allReplace['kategorie'] = $mydb->queryAssocs( 'SELECT * FROM kategorien' );

$mytpl->replaceList( $allReplace );

$napt->setGlobal( 'content', $mytpl->_template['content'] );
$napt->setGlobal( 'pagename', '&Uuml;bersicht' );

?>
