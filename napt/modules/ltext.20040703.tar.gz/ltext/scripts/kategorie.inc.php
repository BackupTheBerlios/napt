<?php

$thisDb = $napt->getDatabase( $cfg[$napt->module]['dsn'] );
$content = $napt->getTemplate( 'kategorie' );
$tmpContent = "";

$httpvar = array();
$httpvar['id'] = $HTTP_GET_VARS['id'];
$content = ereg_replace( '<!-- kategorie.name -->', $thisDb->queryField( 'SELECT name FROM kategorien WHERE id = '. $httpvar['id']) , $content );
$acontent = explode( '<!-- text.list -->', $content );
$content = $acontent[0];

$texte = $thisDb->queryObjects( 'SELECT id, name, beschreibung, grad FROM ltext WHERE kategorie = '.$httpvar['id'] );
foreach ( $texte as $text ) {
	$tmpContent = $acontent[1];
	$tmpContent = ereg_replace( '<!-- text.id -->', $text->id, $tmpContent );
	$tmpContent = ereg_replace( '<!-- text.name -->', htmlentities( $text->name ), $tmpContent );
	$tmpContent = ereg_replace( '<!-- text.beschreibung -->', htmlentities( $text->beschreibung ), $tmpContent );
	$tmpContent = ereg_replace( '<!-- text.grad -->', $text->grad, $tmpContent );
	$content .= $tmpContent;
}
$content .= $acontent[2];

$napt->setGlobal( 'content', $content );
$napt->setGlobal( 'pagename', 'L&uuml;ckentext - Kategorie "'.$thisDb->queryField( 'SELECT name FROM kategorien WHERE id = '. $httpvar['id']).'"' );

?>
