<?php

$content = $napt->getAdminTemplate( 'newkategorie' );
$napt->setGlobal( 'content', $content );
$napt->setGlobal( 'pagename', 'L&uuml;cktentext - neue Kategorie' );

?>