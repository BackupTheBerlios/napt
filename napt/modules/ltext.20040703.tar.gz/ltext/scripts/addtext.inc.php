<?php
/* Formulardaten lesen */
$kategorie = $_POST['kategorie'];
$text = $_POST['text'];
$name = $_POST['name'];
$beschreibung = $_POST['beschreibung'];
$grad = $_POST['grad'];

/* Text parsen */
$atext = explode( '@', $text );
$dbText = '';
$dbLuecken = array();
$count = 0;
foreach ( $atext as $ptext ) {
	if ( ($count % 2) == 0 ) {
		$dbText .= $ptext;
	} else {
		$lueckecount = ($count + 1) / 2;
		$dbText .= ' @'.$lueckecount.' ';
		$dbLuecken[$lueckecount] = $ptext;
	}; 
	$count++;
}

/* Daten eintragen */
$db = $napt->getDatabase( $cfg[$napt->submodule]['dsn'] );
$db->execute( 'INSERT INTO ltext ( name, beschreibung, grad, ltext, kategorie )
					VALUES ( "'.$name.'", "'.$beschreibung.'", '.$grad.', "'.$dbText.'", '.$kategorie.' )' );
$textId = $db->getLastId();
foreach ( $dbLuecken as $kLuecke => $eLuecke ) {
	$db->execute( 'INSERT INTO loesung ( text_id, word_id, word )
						VALUES ( '.$textId.', '.$kLuecke.', "'.$eLuecke.'" )' );
}

?>
