<?php
/* Formulardaten lesen */
$name = $_POST['name'];
$beschreibung = $_POST['beschreibung'];

/* Daten eintragen */
$db = $napt->getDatabase( $cfg[$napt->submodule]['dsn'] );
$db->execute( 'INSERT INTO kategorien ( name, beschreibung )
					VALUES ( "'.$name.'", "'.$beschreibung.'")' );

?>
