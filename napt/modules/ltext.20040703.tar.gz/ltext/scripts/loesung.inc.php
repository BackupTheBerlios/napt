<?php

$ergebnis = array();
$ergebnis['richtig'] = 0;
$ergebnis['falsch'] = 0;
$ergebnis['summe'] = 0;
$ergebnis['prozent'] = 0.0;
$ergebnis['note'] = '';

$thisDb = $napt->getDatabase( $cfg[$napt->module]['dsn'] );
$content = $napt->getTemplate( 'loesung' );

$acontent = explode( '<!-- loesung.list -->', $content );
$content = $acontent[0];

/* Richtigen Lösungen lesen */
$lsg = array();
$loesungen = $thisDb->queryObjects( 'SELECT word_id, word FROM loesung WHERE text_id = '.$HTTP_GET_VARS['text'] );
foreach ( $loesungen as $loesung ) {
	$tmpcontent = $acontent[1];
	$userLoesung = $HTTP_POST_VARS['word_'.$loesung->word_id];

	if ( $loesung->word == $userLoesung ) {
		$wertungLoesung = 'richtig';
		$ergebnis['richtig'] += 1;
	} else {
		$ergebnis['falsch'] += 1;
		$wertungLoesung = 'falsch';
	}
	$lsg[$loesung->word_id] = array( $wertungLoesung, $loesung->word );
	$ergebnis['summe'] += 1;

	$tmpcontent = ereg_replace( '<!-- loesung.user -->', $userLoesung , $tmpcontent );
	$tmpcontent = ereg_replace( '<!-- loesung.lehrer -->', htmlentities( $loesung->word ), $tmpcontent );
	$tmpcontent = ereg_replace( '<!-- loesung.wertung -->', htmlentities( $wertungLoesung ), $tmpcontent );
	$content .= $tmpcontent;
}
$content .= $acontent[2];

$htmltext = '';
$text = $thisDb->queryObject( 'SELECT ltext FROM ltext WHERE id = '.$HTTP_GET_VARS['text'] );
$text->ltext = htmlentities( $text->ltext );
$atext = explode( '@', $text->ltext );
$count = 0; $wordId = 0;
foreach ( $atext as $partText ) {
	if ( $count == 0 ) {
		$htmltext = $partText;
	} else {
		$wordId = substr($partText, 0, strpos( $partText, ' ') );
		if ( $lsg[$wordId][0] == 'richtig' ) {
			$htmltext .= '<span class="richtig">'.$HTTP_POST_VARS['word_'.$wordId].'</span>';
		} else {
			$htmltext .= '<span class="falsch">'.$lsg[$wordId][1].' ('.$HTTP_POST_VARS['word_'.$wordId].')</span>';
		}
		$htmltext .= substr( $partText, strpos( $partText, ' ') );
	}
	$count++;
}

$ergebnis['prozent'] = ($ergebnis['richtig'] / $ergebnis['summe']) * 100;
$ergebnis['note'] = $thisDb->queryField( 'SELECT note FROM note WHERE ('.$ergebnis['prozent'].' >= min_proz) ORDER BY min_proz DESC' );
$content = str_replace( '<!-- loesung.text -->', $htmltext, $content );
$content = str_replace( '<!-- loesung.richtig -->', $ergebnis['richtig'], $content );
$content = str_replace( '<!-- loesung.falsch -->', $ergebnis['falsch'], $content );
$content = str_replace( '<!-- loesung.summe -->', $ergebnis['summe'], $content );
$content = str_replace( '<!-- loesung.prozent -->', $ergebnis['prozent'], $content );
$content = str_replace( '<!-- loesung.note -->', htmlentities( $ergebnis['note'] ), $content );

$napt->setGlobal( 'content', $content );
$napt->setGlobal( 'pagename', 'L&uuml;ckentext - L&ouml;sung' );
?>
