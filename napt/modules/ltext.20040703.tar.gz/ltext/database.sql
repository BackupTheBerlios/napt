-- MySQL dump 8.22
--
-- Host: localhost    Database: ltext
---------------------------------------------------------
-- Server version	3.23.54

--
-- Current Database: ltext
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ ltext;

USE ltext;

--
-- Table structure for table 'kategorien'
--

CREATE TABLE kategorien (
  name varchar(255) default NULL,
  beschreibung tinytext,
  id int(11) NOT NULL auto_increment,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'kategorien'
--


INSERT INTO kategorien VALUES ('deutsch','einfache deutsche S�tze',1);
INSERT INTO kategorien VALUES ('Englisch Klasse5','Englisch Klasse 5 �bungen.',2);

--
-- Table structure for table 'loesung'
--

CREATE TABLE loesung (
  text_id int(11) default NULL,
  word_id int(11) default NULL,
  word varchar(255) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'loesung'
--


INSERT INTO loesung VALUES (1,1,'das');
INSERT INTO loesung VALUES (1,2,'dem');

--
-- Table structure for table 'ltext'
--

CREATE TABLE ltext (
  id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  beschreibung tinytext,
  grad smallint(6) default NULL,
  ltext text,
  kategorie int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'ltext'
--


INSERT INTO ltext VALUES (1,'derdiedas 01','der die das eintr�ge',1,'@1 auto f�hrt. er f�hrt mit @2 auto.',1);

