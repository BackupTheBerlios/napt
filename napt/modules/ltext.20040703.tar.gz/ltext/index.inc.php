<?php
include( 'modules/'.$napt->module.'/config/init.inc.php' );

$napt->setGlobal( "pagename", "L&uuml;ckentext" );

if( $napt->isAllowed( $napt->module, $napt->action ) ) {
   include( 'scripts/'.$napt->action.'.inc.php' );
} 

if( $napt->isAllowed( $napt->module, $napt->view ) ) {
   include( 'scripts/'.$napt->view.'.inc.php' );
} else {
   echo( 'geh nach hause!' );
}
?>
