<?php

$cfg[$napt->module] = array();
$cfg[$napt->module]['dsn'] = 'root:password@localhost/ltext';

?>
