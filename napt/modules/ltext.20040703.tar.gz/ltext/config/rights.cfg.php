<?php

$MODULE_NAME = Misc::getParentDir( __FILE__, false );

$rights[$MODULE_NAME] = array();
$rights[$MODULE_NAME]['overview']       = '*';
$rights[$MODULE_NAME]['kategorie']      = '*';
$rights[$MODULE_NAME]['text']           = '*';
$rights[$MODULE_NAME]['loesung']        = '*';
$rights[$MODULE_NAME]['admin']          = 'admin';
$rights[$MODULE_NAME]['addkategorie']   = 'admin';
$rights[$MODULE_NAME]['newkategorie']   = 'admin';
$rights[$MODULE_NAME]['addtext']        = 'admin';

?>
